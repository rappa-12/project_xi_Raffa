import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final TextEditingController _controllerA = TextEditingController();
  final TextEditingController _controllerB = TextEditingController();
  int _hasil = 0;

  void _hitungTambah() {
    setState(() {
      int a = int.tryParse(_controllerA.text) ?? 0;
      int b = int.tryParse(_controllerB.text) ?? 0;
      _hasil = a + b;
    });
  }

  void _hitungKurang() {
    setState(() {
      int a = int.tryParse(_controllerA.text) ?? 0;
      int b = int.tryParse(_controllerB.text) ?? 0;
      _hasil = a - b;
    });
  }

  void _hitungPerkalian() {
    setState(() {
      int a = int.tryParse(_controllerA.text) ?? 0;
      int b = int.tryParse(_controllerB.text) ?? 0;
      _hasil = a * b;
    });
  }

  void _hitungPembagian() {
    setState(() {
      int a = int.tryParse(_controllerA.text) ?? 0;
      int b = int.tryParse(_controllerB.text) ?? 1; 
      _hasil = b != 0 ? a ~/ b : 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Kalkulator Sederhana")),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(
                controller: _controllerA,
                decoration: InputDecoration(labelText: "Angka A"),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _controllerB,
                decoration: InputDecoration(labelText: "Angka B"),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),

              // Tombol-tombol operasi
              Wrap(
                spacing: 10, 
                runSpacing: 10, 
                children: [
                  ElevatedButton(
                    onPressed: _hitungTambah,
                    child: Text("Tambah"),
                  ),
                  ElevatedButton(
                    onPressed: _hitungKurang,
                    child: Text("Kurang"),
                  ),
                  ElevatedButton(
                    onPressed: _hitungPerkalian,
                    child: Text("Kali"),
                  ),
                  ElevatedButton(
                    onPressed: _hitungPembagian,
                    child: Text("Bagi"),
                  ),
                ],
              ),

              SizedBox(height: 30),
              Text(
                "Hasil: $_hasil",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
