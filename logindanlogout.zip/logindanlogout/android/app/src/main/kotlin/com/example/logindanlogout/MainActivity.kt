package com.example.logindanlogout

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
