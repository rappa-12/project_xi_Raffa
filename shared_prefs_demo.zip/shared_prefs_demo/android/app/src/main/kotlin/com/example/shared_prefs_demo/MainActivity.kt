package com.example.shared_prefs_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
