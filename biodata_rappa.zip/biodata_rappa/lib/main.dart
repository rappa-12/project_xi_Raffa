import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Biodataku',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 0, 0, 0)
          ),
          scaffoldBackgroundColor: const Color.fromARGB(255, 255, 255, 255), // Ganti ini
          useMaterial3: true,
        ),

      home: const MyHomePage(title: 'Biodata Rappa'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.primary,
          centerTitle: true,
          title: Text(title, style: const TextStyle(color: Colors.white)),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: CircleAvatar(
                radius: 60,
                backgroundImage: AssetImage('rrrrr.jpeg'),
              ),
            ),
          
          Center(
            child: Text('Welcome ',
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 21,
              fontWeight: FontWeight.w500
            ),),
           ),
                              const SizedBox(height: 20), 
          Center(
            child: Text('Muhammad Rappa',
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 21,
              fontWeight: FontWeight.w500
            ),),
           ),
                              const SizedBox(height: 20), 
           Center(
            child: Text('XI RPL 1',
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 21,
              fontWeight: FontWeight.w500
            ),),
           ),
                              const SizedBox(height: 20),
            Center(
            child: Text('15 Tahun',
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 21,
              fontWeight: FontWeight.w500
            ),),
           ),
                              const SizedBox(height: 20),
           Center(
            child: Text('Bermain Game',
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 21,
              fontWeight: FontWeight.w500
            ),),
           ),
                              const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}