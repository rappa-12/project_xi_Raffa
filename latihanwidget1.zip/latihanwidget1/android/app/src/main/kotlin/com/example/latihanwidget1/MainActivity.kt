package com.example.latihanwidget1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
